## Salt autocomplete plugin

A copy of the completion script from the
[salt](https://github.com/saltstack/salt/blob/develop/pkg/zsh_completion.zsh)
git repo.
