# Nyan plugin

This plugin adds a command to display [Nyan Cat](https://en.wikipedia.org/wiki/Nyan_Cat) right inside your terminal.

**Plugin is deprecated**. Check [official repo](https://github.com/klange/nyancat) for more information.